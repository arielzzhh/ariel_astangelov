project 1 : war mongole 


tecnology used :
boothstrap html scss javascript css  


flow : 
each turn you choose a card to use then the computer pick (each card represent a unit with hp and dmg it can do to the enemy || the unit must be alive in order to be picked by ither you on your turn or or by the pc  )

the computer will choose randomly 