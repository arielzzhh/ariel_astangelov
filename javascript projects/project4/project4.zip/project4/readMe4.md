project 1 : my account


tecnology used :
boothstrap html  javascript css  (local storage)


flow : 
a banking note app you can put your expanses and incomes the computer will make the transforamtion and show you your balance 
the browser will your balance and enterd actions

