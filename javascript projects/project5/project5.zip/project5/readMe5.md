project 1 : tic tac toe


tecnology used :
boothstrap html  javascript   


flow : 
basic tic tac toe for player versus player its show which turn is it ,you can restart the game 