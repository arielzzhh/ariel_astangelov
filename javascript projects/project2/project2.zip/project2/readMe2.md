project 1 : trivia


tecnology used :
boothstrap html scss javascript css (local storage used for high-score) 


flow : 
basic trivia 4 answers to each questinon in answerdf right get point after each round you high score will be rememberd you
you have 5 lifes each wrong answer lower it by one 

the computer will choose randomly a question 