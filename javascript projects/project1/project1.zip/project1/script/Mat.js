export class Mat {






    static returnNumber(max) {
        return (Math.floor(Math.random() * (max) + 1));


    }
}





