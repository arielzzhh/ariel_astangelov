project 1 : war mongole 


tecnology used :
boothstrap html  javascript css   (local storage used +rest api(countries))


flow : 
represention of the world cuntries including flags population amount 
you can also remember countries you like by pressing the art and the browser will remember you choises 
 